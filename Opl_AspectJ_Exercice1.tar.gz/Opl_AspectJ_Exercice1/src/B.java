
public class B {

	public void print(String msg){
		System.out.println(msg);
	}
}
